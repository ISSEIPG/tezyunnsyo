package com.internousdev.latterwin.action;

import com.opensymphony.xwork2.ActionSupport;

public class ContentPageAction extends ActionSupport {
    public String execute() {
        return SUCCESS;
    }
}
