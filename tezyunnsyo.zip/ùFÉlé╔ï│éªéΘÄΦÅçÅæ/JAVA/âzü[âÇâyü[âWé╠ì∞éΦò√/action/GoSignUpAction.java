package com.internousdev.rensyuu.action;

import com.opensymphony.xwork2.ActionSupport;

/**
 * @author internous
 *
 */
public class GoSignUpAction extends ActionSupport {
	public String execute() {
		return SUCCESS;
	}
}
