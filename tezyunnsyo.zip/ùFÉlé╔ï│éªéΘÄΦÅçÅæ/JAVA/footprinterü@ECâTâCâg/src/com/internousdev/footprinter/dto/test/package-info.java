
/**
 * DTOクラスをまとめる為のパッケージ
 * @author 田中 賢樹
 */
package com.internousdev.footprinter.dto.test;