#include <string>
#include <cstdlib>
#include <sstream>
#include <string>
#include <ctime>

//Whether it uses boost::lexical_cast<T> or not.
#define BOOST_ENABLED

#ifdef BOOST_ENABLED

#include <boost/lexical_cast.hpp>

#endif

namespace Tools{
	typedef std::pair<bool, std::string> cmdResult;
	typedef std::pair<std::string, std::string> fileData;
	typedef std::string String;


	std::string subStr( std::string str, int x, int y ){
		if( x > y ) return "";
		if( x < 0 ) x = 0;
		if( y >= str.size() ) y = str.size() - 1;

		return str.substr( x, y - x + 1 );
	}

	fileData makeFileData(std::string str){
		int result;

		if( (result = str.rfind(".")) != std::string::npos ){
			return fileData(subStr(str, 0, result - 1), subStr(str, result + 1, str.size() - 1));
		}else return fileData(str, "");
	}

	cmdResult runCmd( std::string cmd ){
		FILE* fp;
		char buf[1024];
		std::string rst;

		fp = popen(cmd.c_str(), "r");

		if(!fp){
			return cmdResult(false, "");
		}

		while( memset( buf, 0, sizeof(buf) ), fgets( buf, sizeof(buf), fp ) ){
			rst += buf;
		}

		return cmdResult(true, rst);
	}

  template<typename Ta, typename Tb>
  Ta convertWithSS(Tb tb){
    Ta ta;
    std::stringstream ss;

    ss << tb;

    ss >> ta;

    return ta;
  }

  template<typename T>
  std::string format(const T& t){
#ifdef BOOST_ENABLED
    return boost::lexical_cast<std::string>(t);
#else
    return convertWithSS<std::string>(t);
#endif
  }

  template<typename T, typename... Args>
  std::string format(const T& t, Args... args){
#ifdef BOOST_ENABLED
    return boost::lexical_cast<std::string>(t) + format(args...);
#else
    return convertWithSS<std::string>(t) + format(args...);
#endif
  }

  std::string getLocalTime(){
    std::time_t timer;
    struct tm *t_st;

   std::time(&timer);

   return ctime(&timer);
  }

  namespace json{
   enum class DataType{
    String,
    Array,
  };

   		/*class Data{
   			class HiddenData{
   			public:
   				DataType dt;

   				HiddenData(const DataType& dt):dt(dt){}
   			};
   			class StringData:public HiddenData{
			public:
				std::string str;

   				StringData(const std::string& str):str(str), HiddenData(DataType::String){

   				}
   			};
   			class ArrayData:public HiddenData{
   			public:
   				std::map<std::string, Data> map;

   				ArrayData(const std::map<std::string, Data> m):map(m), HI(DataType::Array){

   				}
   			};

   		public:
   			std::shared_ptr<HiddenData> hd;

   			Data( const std::string &key, const std::string& str ){
   				hd = std::make_shared<StringData>(StringData(str));
   			}
   			Data( const std::map<std::string, Data> &m ){
   				hd = std::make_shared<ArrayData>(ArrayData(m));
   			}

   			const DataType& getDataType(){
   				return hd->dt;
   			}

   			std::map<std::string, Data> getArrayData(){
   				if( hd->dt != DataType::Array ) throw "Type is different.";

   				return std::shared_ptr<ArrayData>(hd)->map;
   			}

   			std::string getStringData(){
   				if( hd->dt != DataType::String ) throw "Type is different.";

   				return std::shared_ptr<StringData>(hd)->str;
   			}
   		}; */
  }
}