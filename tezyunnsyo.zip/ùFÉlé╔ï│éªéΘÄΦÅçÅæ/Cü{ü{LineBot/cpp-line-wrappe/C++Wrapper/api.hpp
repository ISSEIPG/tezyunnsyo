#include <iostream>
#include "../Thrift/TalkService.h"
#include <unordered_map>
#include <thrift/transport/THttpClient.h>
#include <thrift/transport/TTransportException.h>
#include <thrift/protocol/TCompactProtocol.h>
#include <initializer_list>
#include <boost/shared_ptr.hpp>
#include <sstream>
#include "myhttp.h"
#include <string>
#include <numeric>

//#define CATCH_PASS catch(std::exception& e){}catch(apache::thrift::transport::TTransportException& te){}
#define CATCH_PASS catch(...){}

class LineApi{
public:
	boost::shared_ptr<TalkServiceClient> client;
	int64_t revision;
	Profile profile;
	std::vector<Group> groups;
	std::vector<Contact> contacts;
	std::vector<TMessageBoxWrapUp> rooms;

	LineApi() = default;

	void setLastOpRevision(){
		try{
			revision = client->getLastOpRevision();
		}CATCH_PASS
	}

	int getLastOpRevision(){
		return client->getLastOpRevision();
	}	

	std::vector<std::string> getJoinedGroupIds(){
		std::vector<std::string> groupIds;

		try{
			client->getGroupIdsJoined(groupIds);
		}CATCH_PASS

		return groupIds;
	}

	std::vector<Group> getJoinedGroups(){
		std::vector<Group> groups;

		try{
			for( const auto& Id : getJoinedGroupIds() ){
				groups.emplace_back();

				client->getGroup(groups.back(), Id);
			}
		}CATCH_PASS

		return groups;
	}

	Profile getProfile(){
		Profile pf;

		try{
			client->getProfile(pf);
		}CATCH_PASS

		return pf;
	}

	std::vector<std::string> getAllContactIds(){
		std::vector<std::string> contactIds;

		try{
			client->getAllContactIds(contactIds);
		}CATCH_PASS

		return contactIds;
	}

	std::vector<Contact> getAllContacts(){
		std::vector<Contact> contacts;

		try{
			client->getContacts( contacts, getAllContactIds() );
		}CATCH_PASS

		return contacts;
	}

	std::string reissueGroupTicket(const std::string& groupId){
		std::string ticket;

		try{
			client->reissueGroupTicket( ticket, groupId );
		}CATCH_PASS

		return ticket;
	}

	std::string reissueUserTicket(const int64_t& expirationTime, const int32_t& maxUseCount){
		std::string ticket;

		try{
			client->reissueUserTicket( ticket, expirationTime, maxUseCount );
		}CATCH_PASS

		return ticket;
	}

	Message sendMessage(const std::string& toId, const std::string& text){
		Message msg, res;

		try{
			msg.to = toId, msg.text = text;
			msg.from = getProfile().mid;
			msg.__isset.location = false;

			client->sendMessage(res, -1, msg);
			std::cerr << res.text << std::endl;
		}CATCH_PASS

		return res;
	}

	Message sendMessage(const Message& msg){
		Message res;

		try{
			client->sendMessage(res, -1, msg);
		}CATCH_PASS

		return res;
	}

	char cnt = 0;

	std::vector<Operation> longPollRaw(const int& count = 50){
		std::vector<Operation> operations;
		
		if((cnt %= 10) == 0){
			try{
				client->sendDummyPush();
			}catch(...){
				throw "Dummy Error.";
			}
		}
		++cnt;

		try{
			if(getLastOpRevision() <= revision) return operations;
			
			try{
				client->fetchOperations(operations, revision, count);
			}catch(...){
				return operations;
			}

			std::vector<Operation> res;
			res.reserve(operations.size());
			for(auto&& o : operations){
				if(o.revision > revision){
					this->revision = o.revision;
				
					if( o.type != OpType::DUMMY){
						res.emplace_back(o);
					}
				}
			}

			return res;

		}catch(...){
			std::cerr << "error: longPollRaw()" << std::endl;
			
			throw "error: longPollRaw()";
		}
	}
	std::vector<Message> longPoll(const int& count = 50) noexcept{
		std::vector<Operation>	operations;
		std::vector<Message> msgs;
		
		if((cnt %= 10) == 0){
			try{
				client->sendDummyPush();
			}catch(...){
				return msgs;
			}
		}
		++cnt;

		try{
			if(getLastOpRevision() <= revision) return msgs;

			try{
				client->fetchOperations(operations, revision, count);
			}catch(...){
				return msgs;
			}

			for(auto&& o : operations){
				if(o.revision > revision){
					revision = o.revision;
					switch(o.type){
						case OpType::DUMMY:
						break;
						case OpType::END_OF_OPERATION:
							std::cerr << "OPERATION NO OWARI" << std::endl;
							//abort();
						break;
						case OpType::SEND_MESSAGE:
						break;
						case OpType::RECEIVE_MESSAGE:
						msgs.push_back(o.message);
						break;
						default:
						if(_OpType_VALUES_TO_NAMES.count(o.type)){
							std::string name = _OpType_VALUES_TO_NAMES.find((int)o.type)->second;

							std::cerr << name << std::endl;

							if(name.find("GROUP") != std::string::npos){
								refreshGroups();
							}
							else if(name.find("ROOM") != std::string::npos){
								refreshActiveRooms();
							}
							else if(name.find("PROFILE") != std::string::npos ){
								profile = getProfile();
							}
							else if(name.find("CONTACT") != std::string::npos ){
								refreshContacts();
							}
						}
						else
							std::cerr << "NO KEY" << (int)o.type << std::endl;
						break;
					}
				}
			}
		}catch(apache::thrift::transport::TTransportException& te){
			std::cerr << te.what() << std::endl;

			return msgs;
		}catch(TalkException& e){
			std::cerr << e.what() << std::endl;

			return msgs;
		}

		return msgs;
	}

	std::vector<Message> getFetchMessages(){
		std::vector<Message> msgs;

		try{
			client->fetchMessages(msgs, 1, std::numeric_limits<int32_t>::max());
		}CATCH_PASS

		return msgs;
	}

	std::vector<TMessageBoxWrapUp> getJoinedActiveRooms(){
		int start = 1;
		const int count = 50;
		TMessageBoxWrapUpResponse wup;
		std::vector<TMessageBoxWrapUp> vec;

		try{
			while(true){
				client->getMessageBoxCompactWrapUpList(wup, start, count);

				for(auto&& w : wup.messageBoxWrapUpList){
					if(w.messageBox.midType == MIDType::ROOM){
						vec.emplace_back(w);
					}
				}

				if(wup.messageBoxWrapUpList.size() == count) start += count;
				else break;
			}
		}CATCH_PASS

		return vec;
	}

	void refreshGroups(){
		try{
			groups = getJoinedGroups();
		}CATCH_PASS
	}

	void refreshContacts(){
		try{
			contacts = getAllContacts();
		}CATCH_PASS
	}

	void refreshActiveRooms(){
		try{
			rooms = getJoinedActiveRooms();
		}CATCH_PASS
	}

	static const std::string getTalkingArea(const Message& msg){
		if(msg.toType == MIDType::USER){
			return msg.from;
		}else return msg.to;
	}
};
