#pragma once
#include "api.hpp"
#include "../json11/json11.hpp"

constexpr const char* PC_NAME =  "line with black magic";
constexpr const char* MY_IP = "127.0.0.1";

class LineClient: public LineApi{
private:
	static const std::string domain;
	static const std::string session;

	boost::shared_ptr<MyHttpClient> transport;
	boost::shared_ptr<::apache::thrift::protocol::TCompactProtocol> protocol;
public:
	std::string id, pass, certificate, authToken;
	bool isSignedUp = false;

	LineClient() = default;
	LineClient(const LineClient&) = delete;
	LineClient(const LineClient&&) = delete;
	LineClient& operator = (const LineClient&) = delete;
	LineClient&& operator = (const LineClient&&) = delete;

	bool login(const std::string& id, const std::string& pass, const std::string& certificate = "");

	bool login(const std::string& authToken);

	bool login();// QR
private:
	void ready();
};

const std::string LineClient::domain = "gw.line.naver.jp";
const std::string LineClient::session = "/authct/v1/keys/line";

//Mailaddress, Password, Certificate(login without pincode)
bool LineClient::login(const std::string& id, const std::string& pass, const std::string& certificate){
	try{
		LoginResult lr;

		transport = boost::shared_ptr<MyHttpClient>(new MyHttpClient( domain, 80, "/api/v4/TalkService.do" ));

		transport->addHeader(
		{
			{"User-Agent", "DESKTOP:MAC:10.9.4-MAVERICKS-x64(4.1.2)"},
			{"X-Line-Application", "DESKTOPMAC\t10.9.4-MAVERICKS-x64\tMAC\t4.1.2"},
		}
		);

		transport->open();

		protocol = boost::shared_ptr<::apache::thrift::protocol::TCompactProtocol>(
			new ::apache::thrift::protocol::TCompactProtocol(transport)
			);
		client = boost::shared_ptr<TalkServiceClient>(
			new TalkServiceClient(protocol)
			);

		client->loginWithIdentityCredentialForCertificate(
			lr,
			IdentityProvider::LINE,
			id,
			pass,
			true,
			MY_IP,
			PC_NAME,
			certificate
			);

		transport->addHeader("X-Line-Access", lr.verifier);
		if(certificate == ""){
			std::cout << "Enter [" << lr.pinCode << "] on your device." << std::endl;
		
			auto httpData = MyHttp::HttpGETConnection( std::string("http://") + domain, "/Q", transport->headers );
			for(int i = 0; i < 10 && httpData.status != 200; ++i ){
				httpData = MyHttp::HttpGETConnection( std::string("http://") + domain, "/Q", transport->headers );
			}
	
			if( httpData.status != 200 ){
				throw "Couldn't connect.";
			}else std::cout << httpData.body << std::endl;

			std::string verifier, err;

			try{
			
				auto json = json11::Json::parse(httpData.body, err);
				verifier = json["result"]["verifier"].string_value();	

			}catch(std::exception &e){
				return false;
			}
	
			client->loginWithVerifierForCerificate(lr, verifier);
		}else this->certificate = certificate;


		authToken = transport->headers["X-Line-Access"] = lr.authToken;
		this->certificate = lr.certificate;

        auto copy = std::move(transport->headers);

		transport = boost::shared_ptr<MyHttpClient>(new MyHttpClient( domain, 80, "/S4" ));
        transport->headers = std::move(copy);

		transport->open();
		protocol = boost::shared_ptr<::apache::thrift::protocol::TCompactProtocol>(
			new ::apache::thrift::protocol::TCompactProtocol(transport)
			);

		client = boost::shared_ptr<TalkServiceClient>(
			new TalkServiceClient(protocol)
			);
		
		ready();
	}catch(std::exception &e){
		std::cerr << e.what() << std::endl;

		return false;
	}

	return true;
}

//login with authToken
bool LineClient::login(const std::string& authToken){
	try{
		transport = boost::shared_ptr<MyHttpClient>(new MyHttpClient( domain, 80, "/api/v4/TalkService.do" ));
		transport->addHeader(
		{
			{"User-Agent", "DESKTOP:MAC:10.9.4-MAVERICKS-x64(4.1.0)"},
			{"X-Line-Application", "DESKTOPMAC\t10.9.4-MAVERICKS-x64\tMAC\t4.1.0"},
			{"X-Line-Access", authToken},
		}
		);

		transport->open();
		protocol = boost::shared_ptr<::apache::thrift::protocol::TCompactProtocol>(
			new ::apache::thrift::protocol::TCompactProtocol(transport)
			);

		client = boost::shared_ptr<TalkServiceClient>(
			new TalkServiceClient(protocol)
			);

		ready();
	}catch(std::exception &e){
		return false;
	}
	return true;
}

bool LineClient::login(){
	try{
		transport = boost::shared_ptr<MyHttpClient>(new MyHttpClient( domain, 80, "/api/v4/TalkService.do"));
		
		transport->addHeader(
			{
				{"User-Agent", "DESKTOP:MAC:10.9.4-MAVERICKS-x64(4.1.0)"},
				{"X-Line-Application", "DESKTOPMAC\t10.9.4-MAVERICKS-x64\tMAC\t4.1.0"},
			}
		);

		transport->open();
		
		protocol = boost::shared_ptr<::apache::thrift::protocol::TCompactProtocol>(
			new ::apache::thrift::protocol::TCompactProtocol(transport)
		);

		client = boost::shared_ptr<TalkServiceClient>(
			new TalkServiceClient(protocol)
		);

		AuthQrcode qrCode;
		client->getAuthQrcode(qrCode, true, PC_NAME);

		std::cout << "Access line://au/q/" << qrCode.verifier << " on your device." << std::endl;

        transport->addHeader("X-Line-Access", qrCode.verifier);

        auto httpData = MyHttp::HttpGETConnection( std::string("http://") + domain, "/Q", transport->headers );
        for(int i = 0; i < 10 && httpData.status != 200; ++i ){
            httpData = MyHttp::HttpGETConnection( std::string("http://") + domain, "/Q", transport->headers );
        }
            
        if( httpData.status != 200 ){
             throw "Couldn't connect.";
        }else std::cout << httpData.body << std::endl;
        
        std::string verifier, err;
        
        try{
                
            auto json = json11::Json::parse(httpData.body, err);
            verifier = json["result"]["verifier"].string_value();
            
        }catch(std::exception &e){
            return false;
        }
        client->loginWithVerifier(authToken, verifier);
        
        transport->headers["X-Line-Access"] = authToken;
        
        auto copy = std::move(transport->headers);
        
        transport = boost::shared_ptr<MyHttpClient>(new MyHttpClient( domain, 80, "/S4" ));
        transport->headers = std::move(copy);
        
        transport->open();
        protocol = boost::shared_ptr<::apache::thrift::protocol::TCompactProtocol>(
                                                                                   new ::apache::thrift::protocol::TCompactProtocol(transport)
        );
        
        client = boost::shared_ptr<TalkServiceClient>(
                                                      new TalkServiceClient(protocol)
                                                      );
        
        ready();
    }catch(std::exception &e){
        std::cerr << e.what() << std::endl;
        
        return false;
    }
    
    return true;
}

void LineClient::ready(){
	isSignedUp = true;
	
	client->getProfile(profile);
	refreshGroups();
	refreshContacts();
	refreshActiveRooms();
	setLastOpRevision();
}

bool Contact::operator<(const Contact &other) const {
	return mid < other.mid;
}
